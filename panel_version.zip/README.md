<<<<<<< HEAD
# Shizuka-V1.3
# Shizuka-Md WhatsApp Bot V1.3
!7[alt text](https://github.com/Tanmyname/Shizukav1.1/blob/main/icon.png?raw=true?raw=true)
## How to run a Bot on Termux :

**STEP 1**
```
pkg update && pkg upgrade && pkg install bash && pkg install git && git clone https://github.com/Tanmyname/Shizukav1.1.git
```
**STEP 2**
```
cd Shizukav1.1 
```
**STEP 3**
```
chmod 755 run.sh && ./run.sh
```
