#!/bin/bash
echo "system :"; pkg install python3
echo "system :"; pkg install python
echo "system :"; pkg install git 
echo "system :"; pip install colorama
echo "system :"; python3 run.py
